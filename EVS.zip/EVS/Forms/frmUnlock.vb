﻿Imports System.Data.SqlClient
Public Class frmUnlock
    Private Sub FrmUnlock_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AcceptButton = btnLogin
    End Sub

    Private Sub BtnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If txtPass.Text = "" Then
            MessageBox.Show("Enter Password", "EVS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtPass.Focus()
            Exit Sub
        End If

        Try

            con = New SqlConnection(cs)
            con.Open()
            cmd = con.CreateCommand()
            cmd.CommandText = "SELECT Username,Password FROM Users where Username = @d1 and Password=@d2 and UserType=@d3"
            cmd.Parameters.AddWithValue("@d1", lblUser.Text)
            cmd.Parameters.AddWithValue("@d2", txtPass.Text)
            cmd.Parameters.AddWithValue("@d3", lblUType.Text)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                con = New SqlConnection(cs)
                con.Open()
                cmd = con.CreateCommand()
                cmd.CommandText = "SELECT UserType FROM Users where Username=@d3 and Password=@d4 and UserType=@d5"
                cmd.Parameters.AddWithValue("@d3", lblUser.Text)
                cmd.Parameters.AddWithValue("@d4", txtPass.Text)
                cmd.Parameters.AddWithValue("@d5", lblUType.Text)
                rdr = cmd.ExecuteReader()

                '++++++++ CODE TO MAKE MAIN MENU SHOW USER TYPE, LIKE ADMIN, HARDYEM ETC

                If rdr.Read() Then
                    lblUType.Text = rdr.GetValue(0).ToString.Trim
                End If
                If (rdr IsNot Nothing) Then
                    rdr.Close()
                End If
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If


                If lblUType.Text = "Admin" Then
                    'frmMain.lblUser.Text = lblUser.Text
                    'frmMain.lblUserType.Text = lblUType.Text

                    Dim st As String = "Election result panel successfully unlock"
                    LogFunc(lblUser.Text, st)
                    'MsgBox("Successfully logged in !", MsgBoxStyle.Information, "ACCESS GRANTED")
                    Me.Hide()
                    frmElectRes.dgw.Rows.Clear()
                    'frmMain.Show()
                    frmElectRes.ShowDialog()
                End If
            End If
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class