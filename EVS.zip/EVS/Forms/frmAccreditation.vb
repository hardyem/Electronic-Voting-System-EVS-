﻿Imports System.Data.SqlClient
Imports System.IO
Public Class frmAccreditation
    Sub Reset()
        txtMatNo.Text = ""
        txtVotID.Text = ""
        Getdata()
    End Sub

    Private Sub TxtMatNo_TextChanged(sender As Object, e As EventArgs) Handles txtMatNo.TextChanged
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(Username) as [Matric No.], RTRIM(UserType) as [User Type], RTRIM(Password) as [Voter ID] from Users WHERE UserType = 'Voter' and Username like '%" & txtMatNo.Text & "%' order by Username", con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adp.Fill(ds, "Users")
            dgw.DataSource = ds.Tables("Users").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub GetData()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(Username) as [Matric No.], RTRIM(UserType) as [User Type], RTRIM(Password) as [Voter ID] from Users WHERE UserType= 'Voter' order by Username", con)
            'cmd = New SqlCommand("SELECT RTRIM(Post) as [Position], RTRIM(MatricNo) as [Matric No.], RTRIM(NickName) as [Nickname], RTRIM(AspirantID) as [Aspirant ID], RTRIM(StudName) as [Student Name], RTRIM(Lev) as [Level], RTRIM(Gender) as [Gender], RTRIM(Sess) as [Session], RTRIM(SchoolName) as [Faculty], RTRIM(Dept) as [Department], RTRIM(CComb) as [Course Study], RTRIM(PhoneNo) as [Phone No.], RTRIM(Email) as [E-Mail], RTRIM(State) as [Address], RTRIM(Religion) as [Religion], RTRIM(DOB) as [Date of Birth], Photo from Aspirants order by Post, NickName", con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adp.Fill(ds, "Users")
            dgw.DataSource = ds.Tables("Users").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub BtnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Private Sub TxtVotID_TextChanged(sender As Object, e As EventArgs) Handles txtVotID.TextChanged
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(Username) as [Matric No.], RTRIM(UserType) as [User Type], RTRIM(Password) as [Voter ID] from Users WHERE UserType = 'Voter' and Password like '%" & txtVotID.Text & "%' order by Username", con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adp.Fill(ds, "Users")
            dgw.DataSource = ds.Tables("Users").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Dgw_CellContentClick(sender As Object, e As DataGridViewCellEventArgs)

    End Sub

    Private Sub FrmAccreditation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Getdata()
    End Sub
End Class