﻿Imports System.Data.SqlClient
Imports System.IO

Public Class frmAspirant
    Dim s1 As String
    Dim st2 As String
    Dim Photoname As String = ""
    Dim IsImageChanged As Boolean = False

    Sub Reset()
        txtMatNo.Text = ""
        cmbSess.SelectedIndex = -1
        cmbDept.SelectedIndex = -1
        cmbSch.SelectedIndex = -1
        cmbCStudy.SelectedIndex = -1
        cmbReligion.SelectedIndex = -1
        cmbPost.SelectedIndex = -1
        txtNName.Text = ""
        txtAddress.Text = ""
        txtEMail.Text = ""
        txtStudName.Text = ""
        txtPNo.Text = ""
        txtVotID.Text = ""
        cmbLev.SelectedIndex = -1
        cmbSex.SelectedIndex = -1
        dtpDOB.Value = Today
        Picture.Image = My.Resources.photo
        btnSave.Enabled = True
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        cmbSch.Focus()
    End Sub

    Sub fillPost()
        Try
            Dim CN1 As New SqlConnection(cs)
            CN1.Open()
            adp = New SqlDataAdapter()
            adp.SelectCommand = New SqlCommand("SELECT distinct RTRIM(PostName) FROM Posts", CN1)
            ds = New DataSet("ds")
            adp.Fill(ds)
            Dim dtable As DataTable = ds.Tables(0)
            cmbPost.Items.Clear()
            For Each drow As DataRow In dtable.Rows
                cmbPost.Items.Add(drow(0).ToString())
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Sub fillSchool()
        Try
            Dim CN1 As New SqlConnection(cs)
            CN1.Open()
            adp = New SqlDataAdapter()
            adp.SelectCommand = New SqlCommand("SELECT distinct RTRIM(SchoolName) FROM Schools", CN1)
            ds = New DataSet("ds")
            adp.Fill(ds)
            Dim dtable As DataTable = ds.Tables(0)
            cmbSch.Items.Clear()
            For Each drow As DataRow In dtable.Rows
                cmbSch.Items.Add(drow(0).ToString())
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub BtnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        Reset()
    End Sub

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        If txtNName.Text = "" Then
            MessageBox.Show("Please enter Aspirant Nickname", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtNName.Focus()
            Return
        End If
        If txtVotID.Text = "" Then
            MessageBox.Show("Please generate Aspirant ID", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtVotID.Focus()
            Return
        End If
        If cmbSch.Text = "" Then
            MessageBox.Show("Please select school name", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbSch.Focus()
            Return
        End If
        If cmbDept.Text = "" Then
            MessageBox.Show("Please select department", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbDept.Focus()
            Return
        End If
        If cmbCStudy.Text = "" Then
            MessageBox.Show("Please select course of study", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbCStudy.Focus()
            Return
        End If
        If txtMatNo.Text = "" Then
            MessageBox.Show("Please enter student matriculation number", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtMatNo.Focus()
            Return
        End If
        If cmbLev.Text = "" Then
            MessageBox.Show("Please select student Level", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbLev.Focus()
            Return
        End If
        If cmbSex.Text = "" Then
            MessageBox.Show("Please select sex", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbSex.Focus()
            Return
        End If
        If cmbSess.Text = "" Then
            MessageBox.Show("Please select session", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbSess.Focus()
            Return
        End If
        If cmbPost.Text = "" Then
            MessageBox.Show("Please select aspirant position", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbPost.Focus()
            Return
        End If
        Try
            con = New SqlConnection(cs)
            con.Open()
            Dim ct As String = "select MatricNo, NickName from Aspirants where MatricNo=@d1 Or NickName=@d2 Or AspirantID=@d3"
            cmd = New SqlCommand(ct)
            cmd.Parameters.AddWithValue("@d1", txtMatNo.Text)
            cmd.Parameters.AddWithValue("@d2", txtNName.Text)
            cmd.Parameters.AddWithValue("@d3", txtVotID.Text)
            cmd.Connection = con
            rdr = cmd.ExecuteReader()

            If rdr.Read() Then
                MessageBox.Show("Aspirant Already Exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                txtMatNo.Text = ""
                txtMatNo.Focus()
                If (rdr IsNot Nothing) Then
                    rdr.Close()
                End If
                Return
            End If

            con = New SqlConnection(cs)
            con.Open()
            Dim cb As String = "insert into Aspirants(MatricNo, AspirantID, StudName, Lev, Gender, Sess, SchoolName, Dept, CComb, PhoneNo, NickName, Religion, Post, DOB, State, EMail, Photo) VALUES (@d1,@d2,@d3,@d4,@d5,@d6,@d7,@d8,@d9,@d10,@d11,@d12,@d13,@d14,@d15,@d16,@d17)"
            cmd = New SqlCommand(cb)
            cmd.Parameters.AddWithValue("@d1", txtMatNo.Text)
            cmd.Parameters.AddWithValue("@d2", txtVotID.Text)
            cmd.Parameters.AddWithValue("@d3", txtStudName.Text)
            cmd.Parameters.AddWithValue("@d4", cmbLev.Text)
            cmd.Parameters.AddWithValue("@d5", cmbSex.Text)
            cmd.Parameters.AddWithValue("@d6", cmbSess.Text)
            cmd.Parameters.AddWithValue("@d7", cmbSch.Text)
            cmd.Parameters.AddWithValue("@d8", cmbDept.Text)
            cmd.Parameters.AddWithValue("@d9", cmbCStudy.Text)
            cmd.Parameters.AddWithValue("@d10", txtPNo.Text)
            cmd.Parameters.AddWithValue("@d11", txtNName.Text)
            cmd.Parameters.AddWithValue("@d12", cmbReligion.Text)
            cmd.Parameters.AddWithValue("@d13", cmbPost.Text)
            cmd.Parameters.AddWithValue("@d14", dtpDOB.Value.Date)
            cmd.Parameters.AddWithValue("@d15", txtAddress.Text)
            cmd.Parameters.AddWithValue("@d16", txtEMail.Text)
            cmd.Connection = con
            Dim ms As New MemoryStream()
            Dim bmpImage As New Bitmap(Picture.Image)
            bmpImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg)
            Dim data As Byte() = ms.GetBuffer()
            Dim p As New SqlParameter("@d17", SqlDbType.Image)
            p.Value = data
            cmd.Parameters.Add(p)
            cmd.ExecuteReader()
            con.Close()

            'CODE TO INSERT LOGIN DETAILS OF REGISTERED VOTERS TO (TABLE USERS)
            con = New SqlConnection(cs)
            con.Open()
            Dim ct1 As String = "select Username from Users where Username='" & txtMatNo.Text & "'"

            cmd = New SqlCommand(ct1)
            cmd.Connection = con
            rdr = cmd.ExecuteReader()

            If rdr.Read() Then
                'MessageBox.Show("Voter Already Exists", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                'txtUserID.Text = ""
                'txtUserID.Focus()
                If (rdr IsNot Nothing) Then
                    rdr.Close()
                End If
                Return
            End If

            con = New SqlConnection(cs)
            con.Open()
            Dim st1 As String = "Voter"
            Dim cb1 As String = "insert into Users(Username, UserType, Password) VALUES (@d1,@d2,@d3)"
            cmd = New SqlCommand(cb1)
            cmd.Connection = con
            cmd.Parameters.AddWithValue("@d1", txtMatNo.Text)
            cmd.Parameters.AddWithValue("@d2", st1)
            cmd.Parameters.AddWithValue("@d3", txtVotID.Text)
            'cmd.Parameters.AddWithValue("@d7", Now)
            cmd.ExecuteReader()
            con.Close()

            'Dim st As String = "added the new Location '" & txtSchool.Text & "'"
            'LogFunc(lblUser.Text, st)
            LogFunc(lblUser.Text, "added new aspirant '" & txtVotID.Text & "' has Matric no. '" & txtMatNo.Text & "'")

            MessageBox.Show("Successfully Saved", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnSave.Enabled = False
            Getdata()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try

    End Sub

    Private Sub BtnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        If txtNName.Text = "" Then
            MessageBox.Show("Please enter Aspirant Nickname", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtNName.Focus()
            Return
        End If
        If txtVotID.Text = "" Then
            MessageBox.Show("Please generate Aspirant ID", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtVotID.Focus()
            Return
        End If
        If cmbSch.Text = "" Then
            MessageBox.Show("Please select school name", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbSch.Focus()
            Return
        End If
        If cmbDept.Text = "" Then
            MessageBox.Show("Please select department", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbDept.Focus()
            Return
        End If
        If cmbCStudy.Text = "" Then
            MessageBox.Show("Please select course of study", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbCStudy.Focus()
            Return
        End If
        If txtMatNo.Text = "" Then
            MessageBox.Show("Please enter student matriculation number", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtMatNo.Focus()
            Return
        End If
        If cmbSess.Text = "" Then
            MessageBox.Show("Please select session", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbSess.Focus()
            Return
        End If
        If cmbPost.Text = "" Then
            MessageBox.Show("Please select aspirant position", "CAS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbPost.Focus()
            Return
        End If
        Try

            con = New SqlConnection(cs)
            con.Open()

            Dim cb As String = "Update Aspirants set MatricNo=@d1, AspirantID=@d2, StudName=@d3, Lev=@d4, Gender=@d5, Sess=@d6, SchoolName=@d7, Dept=@d8, CComb=@d9, PhoneNo=@d10, NickName=@d11, Religion=@d12, Post=@d13, DOB=@d14, State=@d15, EMail=@d16, Photo=@d17 where MatricNo=@d18"
            cmd = New SqlCommand(cb)
            cmd.Connection = con
            cmd.Parameters.AddWithValue("@d1", txtMatNo.Text)
            cmd.Parameters.AddWithValue("@d2", txtVotID.Text)
            cmd.Parameters.AddWithValue("@d3", txtStudName.Text)
            cmd.Parameters.AddWithValue("@d4", cmbLev.Text)
            cmd.Parameters.AddWithValue("@d5", cmbSex.Text)
            cmd.Parameters.AddWithValue("@d6", cmbSess.Text)
            cmd.Parameters.AddWithValue("@d7", cmbSch.Text)
            cmd.Parameters.AddWithValue("@d8", cmbDept.Text)
            cmd.Parameters.AddWithValue("@d9", cmbCStudy.Text)
            cmd.Parameters.AddWithValue("@d10", txtPNo.Text)
            cmd.Parameters.AddWithValue("@d11", txtNName.Text)
            cmd.Parameters.AddWithValue("@d12", cmbReligion.Text)
            cmd.Parameters.AddWithValue("@d13", cmbPost.Text)
            cmd.Parameters.AddWithValue("@d14", dtpDOB.Value.Date)
            cmd.Parameters.AddWithValue("@d15", txtAddress.Text)
            cmd.Parameters.AddWithValue("@d16", txtEMail.Text)
            Dim ms As New MemoryStream()
            Dim bmpImage As New Bitmap(Picture.Image)
            bmpImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg)
            Dim data As Byte() = ms.GetBuffer()
            Dim p As New SqlParameter("@d17", SqlDbType.Image)
            p.Value = data
            cmd.Parameters.Add(p)
            cmd.Parameters.AddWithValue("@d18", txtMatNoName.Text)
            cmd.ExecuteReader()
            con.Close()


            con = New SqlConnection(cs)
            con.Open()
            Dim st1 As String = "Voter"
            Dim cb1 As String = "update Users set Username=@d1, UserType=@d2, Password=@d3 where Username=@d7"
            cmd = New SqlCommand(cb1)
            cmd.Connection = con
            cmd.Parameters.AddWithValue("@d1", txtMatNo.Text)
            cmd.Parameters.AddWithValue("@d2", st1)
            cmd.Parameters.AddWithValue("@d3", txtVotID.Text)

            cmd.Parameters.AddWithValue("@d7", txtMatNoName.Text)
            cmd.ExecuteReader()
            con.Close()

            LogFunc(lblUser.Text, "updated aspirant '" & txtVotID.Text & "' has matric no. '" & txtMatNo.Text & "'")
            MessageBox.Show("Successfully updated", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnUpdate.Enabled = False
            Getdata()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub

    Private Sub DeleteRecord()

        Try
            Dim RowsAffected As Integer = 0
            con = New SqlConnection(cs)

            Dim cq1 As String = "delete from Users where Username='" & txtMatNo.Text & "'"
            cmd = New SqlCommand(cq1)
            cmd.Connection = con
            'RowsAffected = cmd.ExecuteNonQuery()

            con.Open()
            Dim cq As String = "delete from Aspirants where MatricNo=@d1"
            cmd = New SqlCommand(cq)
            cmd.Parameters.AddWithValue("@d1", txtMatNoName.Text)
            cmd.Connection = con
            RowsAffected = cmd.ExecuteNonQuery()
            If RowsAffected > 0 Then
                LogFunc(lblUser.Text, "deleted the aspirant '" & txtVotID.Text & "' has matric no. '" & txtMatNo.Text & "'")
                MessageBox.Show("Successfully deleted", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Getdata()
                Reset()
            Else
                MessageBox.Show("No Record found", "Sorry", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            End If
            If con.State = ConnectionState.Open Then
                con.Close()

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub

    Private Sub BtnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            If MessageBox.Show("Do you really want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                DeleteRecord()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub Getdata()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(MatricNo), RTRIM(StudName), RTRIM(Lev), RTRIM(Gender), RTRIM(SchoolName), RTRIM(Dept), RTRIM(CComb), RTRIM(PhoneNo), RTRIM(Sess), RTRIM(AspirantID) from Aspirants order by MatricNo", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (rdr.Read() = True)
                dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4), rdr(5), rdr(6), rdr(7), rdr(8), rdr(9))
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub FrmAspirant_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AcceptButton = btnSave
        'Reset()
        Getdata()
        fillSchool()
        fillPost
    End Sub

    Private Sub CmbSch_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbSch.SelectedIndexChanged
        cmbCStudy.Text = ""
        cmbCStudy.Items.Clear()

        cmbDept.Text = ""
        cmbDept.Items.Clear()

        Try
            Dim CN As New SqlConnection(cs)
            CN.Open()
            adp = New SqlDataAdapter()
            'adp.SelectCommand = New SqlCommand("SELECT distinct RTRIM(Department) FROM Dept WHERE School='" & cmbSchool.Text & "'", CN)
            adp.SelectCommand = New SqlCommand("SELECT RTRIM(Dept) FROM Departments WHERE SchoolName='" & cmbSch.Text & "'", CN)
            ds = New DataSet("ds")
            adp.Fill(ds)
            Dim dtable As DataTable = ds.Tables(0)
            cmbDept.Items.Clear()
            For Each drow As DataRow In dtable.Rows
                cmbDept.Items.Add(drow(0).ToString())
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub CmbDept_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbDept.SelectedIndexChanged
        cmbCStudy.Text = ""
        cmbCStudy.Items.Clear()

        Try
            Dim CN As New SqlConnection(cs)
            CN.Open()
            adp = New SqlDataAdapter()
            'adp.SelectCommand = New SqlCommand("SELECT distinct RTRIM(Department) FROM Dept WHERE School='" & cmbSchool.Text & "'", CN)
            adp.SelectCommand = New SqlCommand("SELECT RTRIM(CComb) FROM CStudy WHERE Dept='" & cmbDept.Text & "'", CN)
            ds = New DataSet("ds")
            adp.Fill(ds)
            Dim dtable As DataTable = ds.Tables(0)
            cmbCStudy.Items.Clear()
            For Each drow As DataRow In dtable.Rows
                cmbCStudy.Items.Add(drow(0).ToString())
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Browse_Click(sender As Object, e As EventArgs) Handles Browse.Click
        Try
            With OpenFileDialog1
                .Filter = ("Images |*.png; *.bmp; *.jpg;*.jpeg; *.gif;")
                .FilterIndex = 4
            End With
            'Clear the file name
            OpenFileDialog1.FileName = ""
            If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
                Picture.Image = Image.FromFile(OpenFileDialog1.FileName)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString())
        End Try
    End Sub

    Private Sub BRemove_Click(sender As Object, e As EventArgs) Handles BRemove.Click
        Picture.Image = My.Resources.photo
    End Sub

    Private Sub BStartCapture_Click(sender As Object, e As EventArgs) Handles BStartCapture.Click
        Dim k As New frmCamera
        k.ShowDialog()
        If TempFileNames2.Length > 0 Then

            Picture.Image = Image.FromFile(TempFileNames2)
            Photoname = TempFileNames2
            IsImageChanged = True
        End If
    End Sub

    Private Sub BtnGetData_Click(sender As Object, e As EventArgs) Handles btnGetData.Click
        frmASpirantRecord.Reset()
        frmAspirantRecord.lblSet.Text = "Aspirant Entry"
        frmAspirantRecord.ShowDialog()
    End Sub

    Private Sub BtnGen_Click(sender As Object, e As EventArgs) Handles btnGen.Click
        Dim a, b, c, d, g, f, randomNo As Integer
        Randomize()
        a = Int(10 * Rnd())
        b = Int(10 * Rnd())
        c = Int(10 * Rnd())
        d = Int(10 * Rnd())
        g = Int(10 * Rnd())
        f = Int(10 * Rnd())
        randomNo = a & b & c & d & f & g
        txtVotID.Text = randomNo
    End Sub

    Private Sub TxtMatNo_TextChanged(sender As Object, e As EventArgs) Handles txtMatNo.TextChanged

    End Sub

    Private Sub txtMatNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtMatNo.KeyPress
        Dim keyChar = e.KeyChar

        If Char.IsControl(keyChar) Then
            'Allow all control characters.
        ElseIf Char.IsDigit(keyChar) OrElse keyChar = "/"c Then
            Dim text = Me.txtMatNo.Text
            Dim selectionStart = Me.txtMatNo.SelectionStart
            Dim selectionLength = Me.txtMatNo.SelectionLength

            text = text.Substring(0, selectionStart) & keyChar & text.Substring(selectionStart + selectionLength)

            If Integer.TryParse(text, New Integer) AndAlso text.Length > 16 Then
                'Reject an integer that is longer than 16 digits.
                e.Handled = True
            ElseIf Double.TryParse(text, New Double) AndAlso text.IndexOf("/"c) < text.Length - 3 Then
                'Reject a real number with two many decimal places.
                e.Handled = False
            End If
        Else
            'Reject all other characters.
            e.Handled = True
        End If
    End Sub
End Class