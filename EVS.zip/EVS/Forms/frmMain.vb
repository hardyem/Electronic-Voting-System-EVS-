﻿Imports System.Data.SqlClient
Public Class frmMain
    Private Sub SchoolRegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SchoolRegistrationToolStripMenuItem.Click
        frmSchool.lblUser.Text = lblUser.Text
        frmSchool.Reset()
        frmSchool.ShowDialog()
    End Sub

    Private Sub DepartmentEntryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DepartmentEntryToolStripMenuItem.Click
        frmDepartment.lblUser.Text = lblUser.Text
        frmDepartment.Reset()
        frmDepartment.ShowDialog()
    End Sub

    Private Sub CourseStudyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CourseStudyToolStripMenuItem.Click
        frmCourseStudy.lblUser.Text = lblUser.Text
        frmCourseStudy.Reset()
        frmCourseStudy.ShowDialog()
    End Sub

    Private Sub LecturerEntryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LecturerEntryToolStripMenuItem.Click
        frmVoters.lblUser.Text = lblUser.Text
        frmVoters.Reset()
        frmVoters.ShowDialog()
    End Sub

    Private Sub StudentEntryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentEntryToolStripMenuItem.Click
        frmAspirant.lblUser.Text = lblUser.Text
        frmAspirant.Reset()
        frmAspirant.ShowDialog()
    End Sub

    Private Sub ResultEntryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResultEntryToolStripMenuItem.Click
        frmPost.lblUser.Text = lblUser.Text
        frmPost.Reset()
        frmPost.ShowDialog()
    End Sub

    Private Sub FrmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        electTime()
    End Sub

    Private Sub frmMain_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        'code to disable form close or exit
        e.Cancel = True
    End Sub

    Private Sub VotersLoginToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VotersLoginToolStripMenuItem.Click
        'frmVoterImport.Reset()
        frmVoterImport.lblUser.Text = lblUser.Text
        frmVoterImport.ShowDialog()
    End Sub

    Private Sub AspirantsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AspirantsToolStripMenuItem.Click
        frmAspirantRecord.Reset()
        frmAspirantRecord.ShowDialog()
    End Sub

    Private Sub UserRegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UserRegistrationToolStripMenuItem.Click
        frmNewUser.lblUser.Text = lblUser.Text
        frmNewUser.Reset()
        frmNewUser.ShowDialog()
    End Sub

    Private Sub VoterRegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles VoterRegistrationToolStripMenuItem.Click
        frmNewVoter.Reset()
        frmNewVoter.ShowDialog()
    End Sub

    Private Sub CalculatorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CalculatorToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("Calc.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub NotepadToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NotepadToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("Notepad.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub MSWordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MSWordToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("WinWord.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub WordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WordToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("Wordpad.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub TaskManagerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TaskManagerToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("TaskMgr.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblDateTime.Text = Now.ToString("dd/MM/yyyy hh:mm:ss tt")
        lblCTime.Text = DateTime.Now.ToLongTimeString
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Cursor = Cursors.Default
        Timer2.Enabled = False
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Try
            If MessageBox.Show("Do you really want to logout from application?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                Me.Hide()
                'Me.Close()
                frmLogin.Show()
                frmLogin.txtUser.Text = ""
                frmLogin.txtPass.Text = ""
                frmLogin.txtUser.Focus()
                frmLogin.electTime()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub AccreditationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AccreditationToolStripMenuItem.Click
        frmAccreditation.Reset()
        frmAccreditation.ShowDialog()
    End Sub

    Private Sub CourseRegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CourseRegistrationToolStripMenuItem.Click
        'frmVotLogRec.Reset()
        frmVotLogRec.ShowDialog()
    End Sub

    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        frmLogs.lblUser.Text = lblUser.Text
        frmLogs.Reset()
        frmLogs.ShowDialog()
    End Sub

    Private Sub StudentsToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles StudentsToolStripMenuItem4.Click

        con = New SqlConnection(cs)
        con.Open()
        Dim st1 As String = "End Election"
        Dim ct As String = "select RTRIM(username) from Users where Username=@d1"
        cmd = New SqlCommand(ct)
        cmd.Parameters.AddWithValue("@d1", st1)
        cmd.Connection = con
        rdr = cmd.ExecuteReader()

        If rdr.Read() Then
            frmUnlock.txtPass.Text = ""
            frmUnlock.txtPass.Focus()
            frmUnlock.lblUser.Text = lblUser.Text
            frmUnlock.lblUType.Text = lblUserType.Text
            frmUnlock.ShowDialog()
        Else
            MsgBox("Election is still ongoing wait till it complete !", MsgBoxStyle.Critical, "ELECTION")
        End If
    End Sub

    Private Sub ElectionSetupToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ElectionSetupToolStripMenuItem.Click
        frmElectSetting.lblUser.Text = lblUser.Text
        frmElectSetting.ShowDialog()
        electTime()
    End Sub

    Private Sub ElectionSummaryToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ElectionSummaryToolStripMenuItem.Click
        'con = New SqlConnection(cs)
        'con.Open()
        'Dim st1 As String = "End Election"
        'Dim ct As String = "select RTRIM(username) from Users where Username=@d1"
        'cmd = New SqlCommand(ct)
        'cmd.Parameters.AddWithValue("@d1", st1)
        'cmd.Connection = con
        ' rdr = cmd.ExecuteReader()

        ' If rdr.Read() Then
        frmElectSummary.ShowDialog()
        'Else
        'MsgBox("Election is still ongoing wait till it complete !", MsgBoxStyle.Critical, "ELECTION")
        'End If
    End Sub

    Public Sub electTime()
        'CODE TO CHECK FOR VOTING TIME
        con = New SqlConnection(cs)
        con.Open()
        cmd = con.CreateCommand()
        cmd.CommandText = "SELECT RTRIM(StartTime), RTRIM(EndTime) FROM SetElection"
        'cmd.Parameters.AddWithValue("@d1", lblElectName.Text)
        rdr = cmd.ExecuteReader()
        If rdr.Read() Then
            lblSTime.Text = rdr.GetValue(0)
            lblETime.Text = rdr.GetValue(1)
        End If
    End Sub

    Private Sub ToolStripStatusLabel1_Click(sender As Object, e As EventArgs) Handles ToolStripStatusLabel1.Click
        frmDel.ShowDialog()
    End Sub

    Private Sub ImportsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ImportsToolStripMenuItem.Click

    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        AboutBox1.ShowDialog()
    End Sub

    Private Sub StudentsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StudentsToolStripMenuItem.Click

    End Sub
End Class