﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblUserType = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblUser = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.lblDateTime = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.CourseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ElectionSetupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccreditationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourseRegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SchoolToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SchoolRegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DepartmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DepartmentEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CourseStudyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResultToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResultEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LecturerEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ImportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MultipleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VotersLoginToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RecordsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AspirantsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UtilitiesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UserRegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VoterRegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NotepadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MSWordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TaskManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StudentsToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ElectionSummaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LogoutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.lblCTime = New System.Windows.Forms.Label()
        Me.lblSTime = New System.Windows.Forms.Label()
        Me.lblETime = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.lblUserType, Me.ToolStripStatusLabel2, Me.lblUser, Me.ToolStripStatusLabel3, Me.lblDateTime, Me.ToolStripStatusLabel4})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 590)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1203, 33)
        Me.StatusStrip1.TabIndex = 5
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(112, 28)
        Me.ToolStripStatusLabel1.Text = "Logged in As:"
        '
        'lblUserType
        '
        Me.lblUserType.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserType.Name = "lblUserType"
        Me.lblUserType.Size = New System.Drawing.Size(86, 28)
        Me.lblUserType.Text = "User Type"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(14, 28)
        Me.ToolStripStatusLabel2.Text = ":"
        '
        'lblUser
        '
        Me.lblUser.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUser.Name = "lblUser"
        Me.lblUser.Size = New System.Drawing.Size(94, 28)
        Me.lblUser.Text = "User Name"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(773, 28)
        Me.ToolStripStatusLabel3.Spring = True
        '
        'lblDateTime
        '
        Me.lblDateTime.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateTime.Name = "lblDateTime"
        Me.lblDateTime.Size = New System.Drawing.Size(87, 28)
        Me.lblDateTime.Text = "Date Time"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(22, 28)
        Me.ToolStripStatusLabel4.Text = "a"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CourseToolStripMenuItem, Me.SchoolToolStripMenuItem, Me.DepartmentToolStripMenuItem, Me.ResultToolStripMenuItem, Me.LecturerToolStripMenuItem, Me.StudentsToolStripMenuItem, Me.ImportsToolStripMenuItem, Me.RecordsToolStripMenuItem, Me.UtilitiesToolStripMenuItem, Me.ToolsToolStripMenuItem, Me.ReportsToolStripMenuItem, Me.ToolStripMenuItem1, Me.HelpToolStripMenuItem, Me.AboutToolStripMenuItem, Me.LogoutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1203, 81)
        Me.MenuStrip1.TabIndex = 4
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'CourseToolStripMenuItem
        '
        Me.CourseToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ElectionSetupToolStripMenuItem, Me.AccreditationToolStripMenuItem, Me.CourseRegistrationToolStripMenuItem})
        Me.CourseToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.custom_reports_icon
        Me.CourseToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.CourseToolStripMenuItem.Name = "CourseToolStripMenuItem"
        Me.CourseToolStripMenuItem.Size = New System.Drawing.Size(60, 77)
        Me.CourseToolStripMenuItem.Text = "Files"
        Me.CourseToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ElectionSetupToolStripMenuItem
        '
        Me.ElectionSetupToolStripMenuItem.Name = "ElectionSetupToolStripMenuItem"
        Me.ElectionSetupToolStripMenuItem.Size = New System.Drawing.Size(239, 28)
        Me.ElectionSetupToolStripMenuItem.Text = "Election Setup"
        '
        'AccreditationToolStripMenuItem
        '
        Me.AccreditationToolStripMenuItem.Name = "AccreditationToolStripMenuItem"
        Me.AccreditationToolStripMenuItem.Size = New System.Drawing.Size(239, 28)
        Me.AccreditationToolStripMenuItem.Text = "Accreditation"
        '
        'CourseRegistrationToolStripMenuItem
        '
        Me.CourseRegistrationToolStripMenuItem.Name = "CourseRegistrationToolStripMenuItem"
        Me.CourseRegistrationToolStripMenuItem.Size = New System.Drawing.Size(239, 28)
        Me.CourseRegistrationToolStripMenuItem.Text = "Voters Login Record"
        '
        'SchoolToolStripMenuItem
        '
        Me.SchoolToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SchoolRegistrationToolStripMenuItem})
        Me.SchoolToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.university_icon
        Me.SchoolToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.SchoolToolStripMenuItem.Name = "SchoolToolStripMenuItem"
        Me.SchoolToolStripMenuItem.Size = New System.Drawing.Size(73, 77)
        Me.SchoolToolStripMenuItem.Text = "School"
        Me.SchoolToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'SchoolRegistrationToolStripMenuItem
        '
        Me.SchoolRegistrationToolStripMenuItem.Name = "SchoolRegistrationToolStripMenuItem"
        Me.SchoolRegistrationToolStripMenuItem.Size = New System.Drawing.Size(233, 28)
        Me.SchoolRegistrationToolStripMenuItem.Text = "School Registration"
        '
        'DepartmentToolStripMenuItem
        '
        Me.DepartmentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DepartmentEntryToolStripMenuItem, Me.CourseStudyToolStripMenuItem})
        Me.DepartmentToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.Doc___Google_Docs
        Me.DepartmentToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.DepartmentToolStripMenuItem.Name = "DepartmentToolStripMenuItem"
        Me.DepartmentToolStripMenuItem.Size = New System.Drawing.Size(114, 77)
        Me.DepartmentToolStripMenuItem.Text = "Department"
        Me.DepartmentToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'DepartmentEntryToolStripMenuItem
        '
        Me.DepartmentEntryToolStripMenuItem.Name = "DepartmentEntryToolStripMenuItem"
        Me.DepartmentEntryToolStripMenuItem.Size = New System.Drawing.Size(222, 28)
        Me.DepartmentEntryToolStripMenuItem.Text = "Department Entry"
        '
        'CourseStudyToolStripMenuItem
        '
        Me.CourseStudyToolStripMenuItem.Name = "CourseStudyToolStripMenuItem"
        Me.CourseStudyToolStripMenuItem.Size = New System.Drawing.Size(222, 28)
        Me.CourseStudyToolStripMenuItem.Text = "Course Study"
        '
        'ResultToolStripMenuItem
        '
        Me.ResultToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ResultEntryToolStripMenuItem})
        Me.ResultToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.images_6
        Me.ResultToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ResultToolStripMenuItem.Name = "ResultToolStripMenuItem"
        Me.ResultToolStripMenuItem.Size = New System.Drawing.Size(82, 77)
        Me.ResultToolStripMenuItem.Text = "Position"
        Me.ResultToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'ResultEntryToolStripMenuItem
        '
        Me.ResultEntryToolStripMenuItem.Name = "ResultEntryToolStripMenuItem"
        Me.ResultEntryToolStripMenuItem.Size = New System.Drawing.Size(162, 28)
        Me.ResultEntryToolStripMenuItem.Text = "Post Entry"
        '
        'LecturerToolStripMenuItem
        '
        Me.LecturerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LecturerEntryToolStripMenuItem})
        Me.LecturerToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.engineer_icon
        Me.LecturerToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.LecturerToolStripMenuItem.Name = "LecturerToolStripMenuItem"
        Me.LecturerToolStripMenuItem.Size = New System.Drawing.Size(70, 77)
        Me.LecturerToolStripMenuItem.Text = "Voters"
        Me.LecturerToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'LecturerEntryToolStripMenuItem
        '
        Me.LecturerEntryToolStripMenuItem.Name = "LecturerEntryToolStripMenuItem"
        Me.LecturerEntryToolStripMenuItem.Size = New System.Drawing.Size(178, 28)
        Me.LecturerEntryToolStripMenuItem.Text = "Voters Entry"
        '
        'StudentsToolStripMenuItem
        '
        Me.StudentsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentEntryToolStripMenuItem})
        Me.StudentsToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.Student_3_icon
        Me.StudentsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.StudentsToolStripMenuItem.Name = "StudentsToolStripMenuItem"
        Me.StudentsToolStripMenuItem.Size = New System.Drawing.Size(92, 77)
        Me.StudentsToolStripMenuItem.Text = "Aspirants"
        Me.StudentsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'StudentEntryToolStripMenuItem
        '
        Me.StudentEntryToolStripMenuItem.Name = "StudentEntryToolStripMenuItem"
        Me.StudentEntryToolStripMenuItem.Size = New System.Drawing.Size(216, 28)
        Me.StudentEntryToolStripMenuItem.Text = "Aspirants Entry"
        '
        'ImportsToolStripMenuItem
        '
        Me.ImportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MultipleToolStripMenuItem})
        Me.ImportsToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.add_stock
        Me.ImportsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ImportsToolStripMenuItem.Name = "ImportsToolStripMenuItem"
        Me.ImportsToolStripMenuItem.Size = New System.Drawing.Size(81, 77)
        Me.ImportsToolStripMenuItem.Text = "Imports"
        Me.ImportsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'MultipleToolStripMenuItem
        '
        Me.MultipleToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VotersLoginToolStripMenuItem})
        Me.MultipleToolStripMenuItem.Name = "MultipleToolStripMenuItem"
        Me.MultipleToolStripMenuItem.Size = New System.Drawing.Size(194, 28)
        Me.MultipleToolStripMenuItem.Text = "Multiple Voter"
        '
        'VotersLoginToolStripMenuItem
        '
        Me.VotersLoginToolStripMenuItem.Name = "VotersLoginToolStripMenuItem"
        Me.VotersLoginToolStripMenuItem.Size = New System.Drawing.Size(184, 28)
        Me.VotersLoginToolStripMenuItem.Text = "Login Details"
        '
        'RecordsToolStripMenuItem
        '
        Me.RecordsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AspirantsToolStripMenuItem})
        Me.RecordsToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.reports_icon
        Me.RecordsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.RecordsToolStripMenuItem.Name = "RecordsToolStripMenuItem"
        Me.RecordsToolStripMenuItem.Size = New System.Drawing.Size(82, 77)
        Me.RecordsToolStripMenuItem.Text = "Records"
        Me.RecordsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'AspirantsToolStripMenuItem
        '
        Me.AspirantsToolStripMenuItem.Name = "AspirantsToolStripMenuItem"
        Me.AspirantsToolStripMenuItem.Size = New System.Drawing.Size(156, 28)
        Me.AspirantsToolStripMenuItem.Text = "Aspirants"
        '
        'UtilitiesToolStripMenuItem
        '
        Me.UtilitiesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UserRegistrationToolStripMenuItem, Me.VoterRegistrationToolStripMenuItem, Me.ChangePasswordToolStripMenuItem})
        Me.UtilitiesToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.Utilities_icon
        Me.UtilitiesToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.UtilitiesToolStripMenuItem.Name = "UtilitiesToolStripMenuItem"
        Me.UtilitiesToolStripMenuItem.Size = New System.Drawing.Size(78, 77)
        Me.UtilitiesToolStripMenuItem.Text = "Utilities"
        Me.UtilitiesToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'UserRegistrationToolStripMenuItem
        '
        Me.UserRegistrationToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.images11
        Me.UserRegistrationToolStripMenuItem.Name = "UserRegistrationToolStripMenuItem"
        Me.UserRegistrationToolStripMenuItem.Size = New System.Drawing.Size(220, 28)
        Me.UserRegistrationToolStripMenuItem.Text = "User Registration"
        '
        'VoterRegistrationToolStripMenuItem
        '
        Me.VoterRegistrationToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.new_customers
        Me.VoterRegistrationToolStripMenuItem.Name = "VoterRegistrationToolStripMenuItem"
        Me.VoterRegistrationToolStripMenuItem.Size = New System.Drawing.Size(220, 28)
        Me.VoterRegistrationToolStripMenuItem.Text = "View Voters List"
        '
        'ChangePasswordToolStripMenuItem
        '
        Me.ChangePasswordToolStripMenuItem.Name = "ChangePasswordToolStripMenuItem"
        Me.ChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(220, 28)
        Me.ChangePasswordToolStripMenuItem.Text = "Change Password"
        Me.ChangePasswordToolStripMenuItem.Visible = False
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CalculatorToolStripMenuItem, Me.NotepadToolStripMenuItem, Me.MSWordToolStripMenuItem, Me.WordToolStripMenuItem, Me.TaskManagerToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.Utilities_icon__1_
        Me.ToolsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(60, 77)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        Me.ToolsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'CalculatorToolStripMenuItem
        '
        Me.CalculatorToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.calc
        Me.CalculatorToolStripMenuItem.Name = "CalculatorToolStripMenuItem"
        Me.CalculatorToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.CalculatorToolStripMenuItem.Text = "Calculator"
        '
        'NotepadToolStripMenuItem
        '
        Me.NotepadToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.Notepad1
        Me.NotepadToolStripMenuItem.Name = "NotepadToolStripMenuItem"
        Me.NotepadToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.NotepadToolStripMenuItem.Text = "Notepad"
        '
        'MSWordToolStripMenuItem
        '
        Me.MSWordToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.MS_Word_2_icon1
        Me.MSWordToolStripMenuItem.Name = "MSWordToolStripMenuItem"
        Me.MSWordToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.MSWordToolStripMenuItem.Text = "MS Word"
        '
        'WordToolStripMenuItem
        '
        Me.WordToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.Wordpad_icon__Windows_7_
        Me.WordToolStripMenuItem.Name = "WordToolStripMenuItem"
        Me.WordToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.WordToolStripMenuItem.Text = "Word Pad"
        '
        'TaskManagerToolStripMenuItem
        '
        Me.TaskManagerToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.task_manager1
        Me.TaskManagerToolStripMenuItem.Name = "TaskManagerToolStripMenuItem"
        Me.TaskManagerToolStripMenuItem.Size = New System.Drawing.Size(190, 28)
        Me.TaskManagerToolStripMenuItem.Text = "Task Manager"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentsToolStripMenuItem4, Me.ElectionSummaryToolStripMenuItem})
        Me.ReportsToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.icon_documentation
        Me.ReportsToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(80, 77)
        Me.ReportsToolStripMenuItem.Text = "Reports"
        Me.ReportsToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'StudentsToolStripMenuItem4
        '
        Me.StudentsToolStripMenuItem4.Name = "StudentsToolStripMenuItem4"
        Me.StudentsToolStripMenuItem4.Size = New System.Drawing.Size(223, 28)
        Me.StudentsToolStripMenuItem4.Text = "Election Result"
        '
        'ElectionSummaryToolStripMenuItem
        '
        Me.ElectionSummaryToolStripMenuItem.Name = "ElectionSummaryToolStripMenuItem"
        Me.ElectionSummaryToolStripMenuItem.Size = New System.Drawing.Size(223, 28)
        Me.ElectionSummaryToolStripMenuItem.Text = "Election Summary"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Image = Global.EVS.My.Resources.Resources.log_1281
        Me.ToolStripMenuItem1.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(62, 77)
        Me.ToolStripMenuItem1.Text = "Logs"
        Me.ToolStripMenuItem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.help_icon
        Me.HelpToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(60, 77)
        Me.HelpToolStripMenuItem.Text = "Help"
        Me.HelpToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        Me.HelpToolStripMenuItem.Visible = False
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.Actions_help_about_icon
        Me.AboutToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(69, 77)
        Me.AboutToolStripMenuItem.Text = "About"
        Me.AboutToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'LogoutToolStripMenuItem
        '
        Me.LogoutToolStripMenuItem.Image = Global.EVS.My.Resources.Resources.Logout_icon
        Me.LogoutToolStripMenuItem.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None
        Me.LogoutToolStripMenuItem.Name = "LogoutToolStripMenuItem"
        Me.LogoutToolStripMenuItem.Size = New System.Drawing.Size(76, 77)
        Me.LogoutToolStripMenuItem.Text = "Logout"
        Me.LogoutToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Timer2
        '
        '
        'lblCTime
        '
        Me.lblCTime.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCTime.ForeColor = System.Drawing.Color.Maroon
        Me.lblCTime.Location = New System.Drawing.Point(860, 528)
        Me.lblCTime.Name = "lblCTime"
        Me.lblCTime.Size = New System.Drawing.Size(130, 24)
        Me.lblCTime.TabIndex = 12
        Me.lblCTime.Text = "current time"
        Me.lblCTime.Visible = False
        '
        'lblSTime
        '
        Me.lblSTime.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblSTime.ForeColor = System.Drawing.Color.DarkRed
        Me.lblSTime.Location = New System.Drawing.Point(422, 528)
        Me.lblSTime.Name = "lblSTime"
        Me.lblSTime.Size = New System.Drawing.Size(130, 24)
        Me.lblSTime.TabIndex = 14
        Me.lblSTime.Text = "start time"
        Me.lblSTime.Visible = False
        '
        'lblETime
        '
        Me.lblETime.Font = New System.Drawing.Font("Book Antiqua", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblETime.ForeColor = System.Drawing.Color.DarkRed
        Me.lblETime.Location = New System.Drawing.Point(646, 528)
        Me.lblETime.Name = "lblETime"
        Me.lblETime.Size = New System.Drawing.Size(170, 24)
        Me.lblETime.TabIndex = 13
        Me.lblETime.Text = "end time"
        Me.lblETime.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 81)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1203, 509)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 15
        Me.PictureBox1.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1203, 623)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblSTime)
        Me.Controls.Add(Me.lblETime)
        Me.Controls.Add(Me.lblCTime)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ELECTRONIC VOTING SYSTEM (Version 2.0)"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents lblUserType As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents lblUser As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents lblDateTime As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As ToolStripStatusLabel
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents SchoolToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SchoolRegistrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DepartmentToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DepartmentEntryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CourseStudyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LecturerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LecturerEntryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CourseToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CourseRegistrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StudentEntryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResultToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResultEntryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ImportsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MultipleToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RecordsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UtilitiesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents UserRegistrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CalculatorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NotepadToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MSWordToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WordToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TaskManagerToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents StudentsToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LogoutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AccreditationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VotersLoginToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AspirantsToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VoterRegistrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ElectionSummaryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents Timer1 As Timer
    Friend WithEvents Timer2 As Timer
    Friend WithEvents ElectionSetupToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lblCTime As Label
    Friend WithEvents lblSTime As Label
    Friend WithEvents lblETime As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
