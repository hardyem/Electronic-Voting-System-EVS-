﻿Imports System.Data.SqlClient
Public Class frmElectSetting

    Sub Reset()
        txtPassword.Text = ""
        txtUserID.Text = ""
        cmbSess.SelectedIndex = -1
        txtUserID.Focus()
        txtSTime.Text = DateTime.Now.ToLongTimeString
        txtETime.Text = DateTime.Now.ToLongTimeString
        DateTimePicker1.Value = Now
        DateTimePicker2.Value = Now
        btnSave.Enabled = True
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
        count()
    End Sub
    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
        frmMain.electTime()
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        If txtUserID.Text = "" Then
            MessageBox.Show("Please enter election name", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
            txtUserID.Focus()
            Return
        End If
        If cmbSess.Text = "" Then
            MessageBox.Show("Please select current session", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
            cmbSess.Focus()
            Return
        End If
        If txtSTime.Text = "" Then
            MessageBox.Show("Please enter vote starting time", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
            txtSTime.Focus()
            Return
        End If
        If txtETime.Text = "" Then
            MessageBox.Show("Please enter vote ending time", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
            txtETime.Focus()
            Return
        End If

        Try
            If Val(txtCount.Text) >= 1 Then
                MessageBox.Show("You can't schedule more than one election for this version", "Election", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                con = New SqlConnection(cs)
                con.Open()

                Dim cb As String = "insert into SetElection(Electname, Sess, StartTime, EndTime) VALUES (@d1,@d2,@d3,@d4)"
                cmd = New SqlCommand(cb)
                cmd.Connection = con
                cmd.Parameters.AddWithValue("@d1", txtUserID.Text)
                cmd.Parameters.AddWithValue("@d2", cmbSess.Text)
                cmd.Parameters.AddWithValue("@d3", txtSTime.Text)
                cmd.Parameters.AddWithValue("@d4", txtETime.Text)
                'cmd.Parameters.AddWithValue("@d7", Now)
                cmd.ExecuteReader()
                con.Close()
                Dim st As String = "schedule new election '" & txtUserID.Text & "'"
                LogFunc(lblUser.Text, st)
                MessageBox.Show("Successfully Registered", "Election", MessageBoxButtons.OK, MessageBoxIcon.Information)
                btnSave.Enabled = False
                Getdata()
                count()

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            If MessageBox.Show("Do you really want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                DeleteRecord()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub DeleteRecord()

        Try
            'If txtUserID.Text = "admin" Or txtUserID.Text = "Admin" Then
            'MessageBox.Show("Admin account can not be deleted", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            'Exit Sub
            'End If
            Dim RowsAffected As Integer = 0
            con = New SqlConnection(cs)
            con.Open()
            Dim cq As String = "delete from SetElection where ElectName='" & txtUserID.Text & "'"
            cmd = New SqlCommand(cq)
            cmd.Connection = con
            RowsAffected = cmd.ExecuteNonQuery()
            If RowsAffected > 0 Then
                Dim st As String = "deleted the election '" & txtUserID.Text & "'"
                LogFunc(lblUser.Text, st)
                MessageBox.Show("Successfully deleted", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Getdata()
                count()
                Reset()
            Else
                MessageBox.Show("No Record found", "Sorry", MessageBoxButtons.OK, MessageBoxIcon.Information)
                Reset()
            End If
            If con.State = ConnectionState.Open Then
                con.Close()

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Try
            If txtUserID.Text = "" Then
                MessageBox.Show("Please enter election name", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                txtUserID.Focus()
                Return
            End If
            If cmbSess.Text = "" Then
                MessageBox.Show("Please select current session", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                cmbSess.Focus()
                Return
            End If
            If txtSTime.Text = "" Then
                MessageBox.Show("Please enter vote starting time", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                txtSTime.Focus()
                Return
            End If
            If txtETime.Text = "" Then
                MessageBox.Show("Please enter vote ending time", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                txtETime.Focus()
                Return
            End If

            con = New SqlConnection(cs)
            con.Open()
            Dim cb As String = "update setElection set Electname=@d1, Sess=@d2, StartTime=@d3, EndTime=@d4 where ElectName=@d7"
            cmd = New SqlCommand(cb)
            cmd.Connection = con
            cmd.Parameters.AddWithValue("@d1", txtUserID.Text)
            cmd.Parameters.AddWithValue("@d2", cmbSess.Text)
            cmd.Parameters.AddWithValue("@d3", txtSTime.Text)
            cmd.Parameters.AddWithValue("@d4", txtETime.Text)

            cmd.Parameters.AddWithValue("@d7", TextBox1.Text)
            cmd.ExecuteReader()
            con.Close()
            con.Open()
            Dim st As String = "updated the election '" & txtUserID.Text & "'"
            LogFunc(lblUser.Text, st)
            MessageBox.Show("Successfully updated", "Election Info", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnUpdate.Enabled = False
            Getdata()
            count()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub
    Public Sub Getdata()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(Electname), RTRIM(Sess), RTRIM(StartTime), RTRIM(EndTime) from SetElection order by Electname", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (rdr.Read() = True)
                dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3))
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click
        Reset()
    End Sub


    Private Sub dgw_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles dgw.RowPostPaint
        Dim strRowNumber As String = (e.RowIndex + 1).ToString()
        Dim size As SizeF = e.Graphics.MeasureString(strRowNumber, Me.Font)
        If dgw.RowHeadersWidth < Convert.ToInt32((size.Width + 20)) Then
            dgw.RowHeadersWidth = Convert.ToInt32((size.Width + 20))
        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(strRowNumber, Me.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))

    End Sub

    Private Sub frmElectSetting_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        AcceptButton = btnSave
        Getdata()
        count()
        txtSTime.Text = DateTime.Now.ToLongTimeString
        txtETime.Text = DateTime.Now.ToLongTimeString
    End Sub

    Private Sub dgw_MouseClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgw.MouseClick
        Try
            Dim dr As DataGridViewRow = dgw.SelectedRows(0)
            txtUserID.Text = dr.Cells(0).Value.ToString()
            TextBox1.Text = dr.Cells(0).Value.ToString()
            cmbSess.Text = dr.Cells(1).Value.ToString()
            txtSTime.Text = dr.Cells(2).Value.ToString()
            txtETime.Text = dr.Cells(3).Value.ToString()

            'btnUpdate.Enabled = True
            'btnDelete.Enabled = True
            btnUpdate.Enabled = False
            btnDelete.Enabled = False
            btnSave.Enabled = False
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub count()
        Try
            'con = New SqlConnection(cs)
            'con.Open()
            'Dim ct As String = "select Username from Users where Username='" & txtUserID.Text & "'"

            con = New SqlConnection(cs)
            con.Open()
            'cmd = New SqlCommand("Select Count(distinct Attendance.AttendanceID) from Students,Courses,Attendance,AttendanceMaster where Students.Dept=Courses.Dept and AttendanceMaster.ID=Attendance.AttendanceID and Attendance.MatricNo=Students.MatricNo and Attendance.Sess=@d1 and Courses.CCode=@d2 and Students.Dept=@d3 and AttendanceMaster.AttendanceType=@d4 and Attendance.Date between @date1 and @date2", con)
            cmd = New SqlCommand("Select Count(*) from SetElection", con)
            'cmd.Parameters.AddWithValue("@d4", cmbAttendanceType.Text)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                txtCount.Text = rdr.GetValue(0)
            End If
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click
        btnUpdate.Enabled = True
        btnDelete.Enabled = True
    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
    End Sub
End Class
