﻿Imports System.Data.SqlClient
Imports System.IO

Public Class frmBallot

    Public Sub Getdata1()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT Distinct RTRIM(Post) from Aspirants", con)
            'cmd = New SqlCommand("SELECT RTRIM(PostName) from Posts order by PostName", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            DataGridView1.Rows.Clear()
            While (rdr.Read() = True)
                DataGridView1.Rows.Add(rdr(0))
            End While

            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub DataGridView1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseClick
        Try
            If DataGridView1.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = DataGridView1.SelectedRows(0)
                'txtPostName.Text = dr.Cells(0).Value.ToString()
                txtPost.Text = dr.Cells(0).Value.ToString()
                Picture.Image = Nothing
                Getdata()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub FrmBallot_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Getdata1()
        GetdataB()
        electName()
        Picture.Image = Nothing
    End Sub

    Public Sub Getdata()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(StudName), RTRIM(MatricNo), RTRIM(Post), RTRIM(NickName), Photo from Aspirants WHERE Post='" & txtPost.Text & "' order by Post, NickName", con)
            '----> Post like '%" & txtPost.Text & "%'
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (rdr.Read() = True)
                dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4))
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub GetdataB()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(Post), RTRIM(NickName) from Temp_Ballot WHERE Username like '%" & lblUser.Text & "%' order by Post, NickName", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            DataGridView2.Rows.Clear()
            While (rdr.Read() = True)
                DataGridView2.Rows.Add(rdr(0), rdr(1))
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub TSave()
        Try
            con = New SqlConnection(cs)
            con.Open()
            Dim ct As String = "select Username, Post, NickName from Temp_Ballot where Username=@d1 and Post=@d2"
            cmd = New SqlCommand(ct)
            cmd.Parameters.AddWithValue("@d1", lblUser.Text)
            cmd.Parameters.AddWithValue("@d2", txtPostB.Text)
            cmd.Connection = con
            rdr = cmd.ExecuteReader()

            If rdr.Read() Then
                con = New SqlConnection(cs)
                con.Open()
                Dim cb2 As String = "Update Temp_Ballot set NickName=@d3, MatricNo=@d4, StudName=@d5 where Username=@d1 and Post=@d2"
                cmd = New SqlCommand(cb2)
                cmd.Connection = con
                cmd.Parameters.AddWithValue("@d1", lblUser.Text)
                cmd.Parameters.AddWithValue("@d2", txtPostB.Text)
                cmd.Parameters.AddWithValue("@d3", txtNNameB.Text)
                cmd.Parameters.AddWithValue("@d4", txtMNoB.Text)
                cmd.Parameters.AddWithValue("@d5", txtCandNameB.Text)
                cmd.ExecuteReader()
                con.Close()
                GetdataB()
            Else

                con = New SqlConnection(cs)
                con.Open()

                Dim cb As String = "insert into Temp_Ballot(Username, Post, Nickname, MatricNo, StudName) VALUES (@d1,@d2,@d3,@d4,@d5)"
                cmd = New SqlCommand(cb)
                cmd.Connection = con
                cmd.Parameters.AddWithValue("@d1", lblUser.Text)
                cmd.Parameters.AddWithValue("@d2", txtPostB.Text)
                cmd.Parameters.AddWithValue("@d3", txtNNameB.Text)
                cmd.Parameters.AddWithValue("@d4", txtMNoB.Text)
                cmd.Parameters.AddWithValue("@d5", txtCandNameB.Text)
                'cmd.Parameters.AddWithValue("@d7", Now)
                cmd.ExecuteReader()
                con.Close()
                'MessageBox.Show("Successfully Registered", "User", MessageBoxButtons.OK, MessageBoxIcon.Information)
                'btnSave.Enabled = False
                GetdataB()
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub

    Private Sub Dgw_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgw.CellContentClick

    End Sub

    Private Sub dgw_MouseClick(sender As Object, e As MouseEventArgs) Handles dgw.MouseClick
        Try
            If dgw.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgw.SelectedRows(0)
                ' Dim drs As DataGridViewRow = DataGridView2.SelectedRows(0)
                txtCandNameB.Text = dr.Cells(0).Value.ToString()
                txtMNoB.Text = dr.Cells(1).Value.ToString()
                txtPostB.Text = dr.Cells(2).Value.ToString()
                txtNNameB.Text = dr.Cells(3).Value.ToString()
                Dim data As Byte() = DirectCast(dr.Cells(4).Value, Byte())
                Dim ms As New MemoryStream(data)
                Picture.Image = Image.FromStream(ms)
                TSave()
                ' Else
                '   Picture.Image = Nothing
                'Getdata()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        Try
            If MessageBox.Show("Do you really want to logout from application?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                Me.Hide()
                frmLogin.Show()
                frmLogin.txtUser.Text = ""
                frmLogin.txtPass.Text = ""
                frmLogin.txtUser.Focus()
                frmLogin.electTime()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ResultToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ResultToolStripMenuItem.Click
        Try
            If MessageBox.Show("Do you really want to submit your ballot?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                'Me.Hide()
                If MessageBox.Show("You won't be able to make any changes after submission, Do you want to Proceed?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
                    'Me.Hide()
                    BSave()
                End If
                'BSave()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub BSave()
        Try
            con = New SqlConnection(cs)
            con.Open()
            Dim ct As String = "select MatricNo, Time from Ballot where MatricNo=@d1"
            cmd = New SqlCommand(ct)
            cmd.Parameters.AddWithValue("@d1", lblUser.Text)
            'cmd.Parameters.AddWithValue("@d2", lblDateTime.Text)
            cmd.Connection = con
            rdr = cmd.ExecuteReader()

            If rdr.Read() Then
                MessageBox.Show("You have already submitted your ballot", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                If (rdr IsNot Nothing) Then
                    rdr.Close()
                End If
                Return
            Else

                con = New SqlConnection(cs)
                con.Open()

                Dim cb As String = "insert into Ballot(MatricNo, Time) VALUES (@d1,@d2)"
                cmd = New SqlCommand(cb)
                cmd.Connection = con
                cmd.Parameters.AddWithValue("@d1", lblUser.Text)
                cmd.Parameters.AddWithValue("@d2", lblDateTime.Text)
                'cmd.Parameters.AddWithValue("@d3", txtNNameB.Text)
                'cmd.Parameters.AddWithValue("@d7", Now)
                cmd.ExecuteReader()
                con.Close()
                MessageBox.Show("Ballot successfully submitted", "EVS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                'GetdataB()
            End If
            Me.Close()
            frmLogin.Show()
            frmLogin.txtUser.Text = ""
            frmLogin.txtPass.Text = ""
            frmLogin.txtUser.Focus()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
        End Try
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblDateTime.Text = Now.ToString("dd/MM/yyyy hh:mm:ss tt")
        lblCTime.Text = DateTime.Now.ToLongTimeString
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Cursor = Cursors.Default
        Timer2.Enabled = False
    End Sub

    Public Sub electName()
        con = New SqlConnection(cs)
        con.Open()
        cmd = con.CreateCommand()
        cmd.CommandText = "SELECT RTRIM(ElectName) FROM SetElection"
        'cmd.Parameters.AddWithValue("@d1", lblElectName.Text)
        rdr = cmd.ExecuteReader()
        If rdr.Read() Then
            lblElectName.Text = rdr.GetValue(0)
            'lblLev.Text = rdr.GetValue(1)
        End If
    End Sub

    Private Sub dgw_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles dgw.RowPostPaint
        Dim strRowNumber As String = (e.RowIndex + 1).ToString()
        Dim size As SizeF = e.Graphics.MeasureString(strRowNumber, Me.Font)
        If dgw.RowHeadersWidth < Convert.ToInt32((size.Width + 20)) Then
            dgw.RowHeadersWidth = Convert.ToInt32((size.Width + 20))
        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(strRowNumber, Me.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))

    End Sub
End Class