﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDel
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDel))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Button15)
        Me.Panel1.Controls.Add(Me.Button14)
        Me.Panel1.Controls.Add(Me.Button13)
        Me.Panel1.Controls.Add(Me.Button11)
        Me.Panel1.Controls.Add(Me.Button12)
        Me.Panel1.Controls.Add(Me.Button7)
        Me.Panel1.Controls.Add(Me.Button8)
        Me.Panel1.Controls.Add(Me.Button9)
        Me.Panel1.Controls.Add(Me.Button10)
        Me.Panel1.Controls.Add(Me.Button6)
        Me.Panel1.Controls.Add(Me.Button5)
        Me.Panel1.Controls.Add(Me.Button4)
        Me.Panel1.Controls.Add(Me.Button3)
        Me.Panel1.Controls.Add(Me.Button2)
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Location = New System.Drawing.Point(15, 16)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(513, 215)
        Me.Panel1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(19, 17)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(114, 41)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Users-Voters"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(139, 17)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(114, 41)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "SetElection"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(259, 17)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(114, 41)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Voters"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(379, 17)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(114, 41)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "Departments"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(139, 111)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(114, 41)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "Temp_PB"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(19, 111)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(114, 41)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "Ballot"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(19, 158)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(114, 41)
        Me.Button7.TabIndex = 9
        Me.Button7.Text = "Temp_Ballot"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(379, 64)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(114, 41)
        Me.Button8.TabIndex = 8
        Me.Button8.Text = "PrintVote"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(259, 64)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(114, 41)
        Me.Button9.TabIndex = 7
        Me.Button9.Text = "CStudy"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(139, 64)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(114, 41)
        Me.Button10.TabIndex = 6
        Me.Button10.Text = "Aspirants"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(379, 111)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(114, 41)
        Me.Button11.TabIndex = 11
        Me.Button11.Text = "Winner"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(259, 111)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(114, 41)
        Me.Button12.TabIndex = 10
        Me.Button12.Text = "Temp_Winner"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(198, 158)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(114, 41)
        Me.Button13.TabIndex = 12
        Me.Button13.Text = "Close"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(19, 64)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(114, 41)
        Me.Button14.TabIndex = 13
        Me.Button14.Text = "Users-Officer"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(379, 158)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(114, 41)
        Me.Button15.TabIndex = 14
        Me.Button15.Text = "Users-EndElect"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'frmDel
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SteelBlue
        Me.ClientSize = New System.Drawing.Size(546, 247)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmDel"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frmDel"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents Button10 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Button12 As Button
    Friend WithEvents Button13 As Button
    Friend WithEvents Button14 As Button
    Friend WithEvents Button15 As Button
End Class
