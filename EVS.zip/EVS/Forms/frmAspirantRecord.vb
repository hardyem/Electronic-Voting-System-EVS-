﻿Imports System.Data.SqlClient
Imports System.IO
Public Class frmAspirantRecord
    Sub Reset()
        cmbPost.Text = ""
        txtNName.Text = ""
        GetData()
    End Sub
    Private Sub btnReset_Click(sender As System.Object, e As System.EventArgs) Handles btnReset.Click
        Reset()
    End Sub

    Public Sub GetData()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(Post) as [Position], RTRIM(MatricNo) as [Matric No.], RTRIM(NickName) as [Nickname], RTRIM(AspirantID) as [Aspirant ID], RTRIM(StudName) as [Student Name], RTRIM(Lev) as [Level], RTRIM(Gender) as [Gender], RTRIM(Sess) as [Session], RTRIM(SchoolName) as [Faculty], RTRIM(Dept) as [Department], RTRIM(CComb) as [Course Study], RTRIM(PhoneNo) as [Phone No.], RTRIM(Email) as [E-Mail], RTRIM(State) as [Address], RTRIM(Religion) as [Religion], RTRIM(DOB) as [Date of Birth], Photo from Aspirants order by Post, NickName", con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adp.Fill(ds, "Aspirant")
            dgw.DataSource = ds.Tables("Aspirant").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub txtNName_TextChanged(sender As System.Object, e As System.EventArgs) Handles txtNName.TextChanged
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(Post) as [Position], RTRIM(MatricNo) as [Matric No.], RTRIM(NickName) as [Nickname], RTRIM(AspirantID) as [Aspirant ID], RTRIM(StudName) as [Student Name], RTRIM(Lev) as [Level], RTRIM(Gender) as [Gender], RTRIM(Sess) as [Session], RTRIM(SchoolName) as [Faculty], RTRIM(Dept) as [Department], RTRIM(CComb) as [Course Study], RTRIM(PhoneNo) as [Phone No.], RTRIM(Email) as [E-Mail], RTRIM(State) as [Address], RTRIM(Religion) as [Religion], RTRIM(DOB) as [Date of Birth], Photo from Aspirants where NickName like '%" & txtNName.Text & "%' order by Post, NickName", con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adp.Fill(ds, "Aspirants")
            dgw.DataSource = ds.Tables("Aspirants").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Sub fillPost()
        Try
            Dim CN1 As New SqlConnection(cs)
            CN1.Open()
            adp = New SqlDataAdapter()
            adp.SelectCommand = New SqlCommand("SELECT Distinct RTRIM(Post) from Aspirants", CN1)
            'adp.SelectCommand = New SqlCommand("SELECT distinct RTRIM(PostName) FROM Posts", CN1)
            ds = New DataSet("ds")
            adp.Fill(ds)
            Dim dtable As DataTable = ds.Tables(0)
            cmbPost.Items.Clear()
            For Each drow As DataRow In dtable.Rows
                cmbPost.Items.Add(drow(0).ToString())
            Next

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub
    Private Sub FrmAspirantRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        fillPost()
        GetData()
    End Sub

    Private Sub CmbPost_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbPost.SelectedIndexChanged
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(Post) as [Position], RTRIM(MatricNo) as [Matric No.], RTRIM(NickName) as [Nickname], RTRIM(AspirantID) as [Aspirant ID], RTRIM(StudName) as [Student Name], RTRIM(Lev) as [Level], RTRIM(Gender) as [Gender], RTRIM(Sess) as [Session], RTRIM(SchoolName) as [Faculty], RTRIM(Dept) as [Department], RTRIM(CComb) as [Course Study], RTRIM(PhoneNo) as [Phone No.], RTRIM(Email) as [E-Mail], RTRIM(State) as [Address], RTRIM(Religion) as [Religion], RTRIM(DOB) as [Date of Birth], Photo from Aspirants where Post='" & cmbPost.Text & "' order by Post, NickName", con)
            adp = New SqlDataAdapter(cmd)
            ds = New DataSet()
            adp.Fill(ds, "Aspirants")
            dgw.DataSource = ds.Tables("Aspirants").DefaultView
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_MouseClick(sender As Object, e As System.Windows.Forms.MouseEventArgs) Handles dgw.MouseClick
        Try
            If dgw.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = dgw.SelectedRows(0)
                If lblSet.Text = "Aspirant Entry" Then
                    Me.Hide()
                    frmAspirant.Show()
                    frmAspirant.cmbPost.Text = dr.Cells(0).Value.ToString()
                    frmAspirant.txtMatNo.Text = dr.Cells(1).Value.ToString()
                    frmAspirant.txtMatNoName.Text = dr.Cells(1).Value.ToString()
                    frmAspirant.txtNName.Text = dr.Cells(2).Value.ToString()
                    frmAspirant.txtVotID.Text = dr.Cells(3).Value.ToString()
                    frmAspirant.txtStudName.Text = dr.Cells(4).Value.ToString()
                    frmAspirant.cmbLev.Text = dr.Cells(5).Value.ToString()
                    frmAspirant.cmbSex.Text = dr.Cells(6).Value.ToString()
                    frmAspirant.cmbSess.Text = dr.Cells(7).Value.ToString()
                    frmAspirant.cmbSch.Text = dr.Cells(8).Value.ToString()
                    frmAspirant.cmbDept.Text = dr.Cells(9).Value.ToString()
                    frmAspirant.cmbCStudy.Text = dr.Cells(10).Value.ToString()
                    frmAspirant.txtPNo.Text = dr.Cells(11).Value.ToString()
                    frmAspirant.txtEMail.Text = dr.Cells(12).Value.ToString()
                    frmAspirant.txtAddress.Text = dr.Cells(13).Value.ToString()
                    frmAspirant.cmbReligion.Text = dr.Cells(14).Value.ToString()
                    frmAspirant.dtpDOB.Text = dr.Cells(15).Value.ToString()
                    Dim data As Byte() = DirectCast(dr.Cells(16).Value, Byte())
                    Dim ms As New MemoryStream(data)
                    frmAspirant.Picture.Image = Image.FromStream(ms)
                    'con = New SqlConnection(cs)
                    'con.Open()
                    ' cmd = New SqlCommand("SELECT DocID,DocName from Student,Document,StudentDocSubmitted where Student.AdmissionNo=StudentDocSubmitted.AdmissionNo and Document.Doc_ID=StudentDocSubmitted.DocID and Student.AdmissionNo=@d1", con)
                    'cmd.Parameters.AddWithValue("@d1", dr.Cells(0).Value)
                    'rdr = cmd.ExecuteReader()
                    ' While rdr.Read()

                    'Dim lst As New ListViewItem()
                    'lst.SubItems.Add(rdr(0))
                    'lst.SubItems.Add(rdr(1).ToString().Trim())
                    'frmStudent.ListView1.Items.Add(lst)
                    'End While
                    frmAspirant.btnDelete.Enabled = True
                    frmAspirant.btnUpdate.Enabled = True
                    frmAspirant.btnSave.Enabled = False
                    'con = New SqlConnection(cs)
                    'con.Open()
                    ' cmd = con.CreateCommand()
                    ' cmd.CommandText = "SELECT Session FROM Student where AdmissionNo=@d1"
                    ' cmd.Parameters.AddWithValue("@d1", dr.Cells(0).Value)
                    ' rdr = cmd.ExecuteReader()
                    ' If rdr.Read() Then
                    ' frmStudent.cmbSession.Text = rdr.GetValue(0)
                    'End If
                    If (rdr IsNot Nothing) Then
                        rdr.Close()
                    End If
                    If con.State = ConnectionState.Open Then
                            con.Close()
                        End If
                        lblSet.Text = ""
                    End If
                End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgw_RowPostPaint(sender As Object, e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles dgw.RowPostPaint
        Dim strRowNumber As String = (e.RowIndex + 1).ToString()
        Dim size As SizeF = e.Graphics.MeasureString(strRowNumber, Me.Font)
        If dgw.RowHeadersWidth < Convert.ToInt32((size.Width + 20)) Then
            dgw.RowHeadersWidth = Convert.ToInt32((size.Width + 20))
        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(strRowNumber, Me.Font, b, e.RowBounds.Location.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))

    End Sub

    Private Sub Dgw_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgw.CellContentClick

    End Sub
End Class