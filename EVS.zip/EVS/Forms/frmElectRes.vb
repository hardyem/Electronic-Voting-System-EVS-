﻿Imports System.Data.SqlClient
Imports System.IO
Public Class frmElectRes
    Public Sub Getdata1()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT Distinct RTRIM(Post) from Aspirants", con)
            'cmd = New SqlCommand("SELECT RTRIM(PostName) from Posts order by PostName", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            DataGridView1.Rows.Clear()
            While (rdr.Read() = True)
                DataGridView1.Rows.Add(rdr(0))
            End While

            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub DataGridView1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles DataGridView1.MouseClick
        Try
            If DataGridView1.Rows.Count > 0 Then
                Dim dr As DataGridViewRow = DataGridView1.SelectedRows(0)
                'txtPostName.Text = dr.Cells(0).Value.ToString()
                txtPost.Text = dr.Cells(0).Value.ToString()
                'Picture.Image = Nothing
                Getdata()
                SaveCand()
                GetWinner()
                GetdataNew()
                GetWinnerOnly()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub Getdata()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(StudName), RTRIM(Temp_Ballot.MatricNo), RTRIM(Post), RTRIM(NickName), Count(NickName) from Temp_Ballot, Ballot WHERE Post ='" & txtPost.Text & "' and Temp_Ballot.Username=Ballot.MatricNo Group by StudName, Temp_Ballot.MatricNo, Post, Nickname order by Post, 5, NickName", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            dgw.Rows.Clear()
            While (rdr.Read() = True)
                dgw.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4))
                'dgw.Rows.Add(rdr(0), rdr(1), rdr(2))
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub GetdataNew()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(StudName), RTRIM(MatricNo), RTRIM(Post), RTRIM(NickName), RTRIM(Votes), RTRIM(Status) from Winner WHERE Post ='" & txtPost.Text & "' order by CAST(Votes as int) DESC, Nickname", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            DataGridView2.Rows.Clear()
            While (rdr.Read() = True)
                DataGridView2.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4), rdr(5))
                'dgw.Rows.Add(rdr(0), rdr(1), rdr(2))
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub GetWinnerOnly()
        Try
            con = New SqlConnection(cs)
            con.Open()
            cmd = New SqlCommand("SELECT RTRIM(StudName), RTRIM(MatricNo), RTRIM(Post), RTRIM(NickName), RTRIM(Votes), RTRIM(Status) from Winner WHERE Post ='" & txtPost.Text & "' and (Status='Winner' or Status='Tie') order by CAST(Votes as int) DESC", con)
            'cmd = New SqlCommand("SELECT RTRIM(StudName), RTRIM(MatricNo), RTRIM(Post), RTRIM(NickName), RTRIM(Votes), RTRIM(Status) from Winner order by Post, Status DESC", con)
            rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
            DataGridView3.Rows.Clear()
            While (rdr.Read() = True)
                DataGridView3.Rows.Add(rdr(0), rdr(1), rdr(2), rdr(3), rdr(4), rdr(5))
            End While
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub SaveCand()
        Try
            For Each row As DataGridViewRow In dgw.Rows
                con = New SqlConnection(cs)
                con.Open()
                Dim ct As String = "Select StudName, MatricNo, Post, Nickname, Votes, Status from PrintVote where Post=@d1 and Nickname=@d2 and MatricNo=@d3"
                cmd = New SqlCommand(ct)
                cmd.Connection = con
                cmd.Parameters.AddWithValue("@d1", row.Cells(2).Value)
                cmd.Parameters.AddWithValue("@d2", row.Cells(3).Value)
                cmd.Parameters.AddWithValue("@d3", row.Cells(1).Value)
                'cmd.Parameters.AddWithValue("@d4", row.Cells(5).Value)
                rdr = cmd.ExecuteReader()
                If rdr.Read() Then
                    '   nothing here
                    'i want to write code to update if a record is already written here.
                    'If Val(row.Cells(4).Value) = Val(row.Cells(4).Value) Then
                    'nothing 
                    'Else
                    con = New SqlConnection(cs)
                        con.Open()
                        Dim cb2 As String = "Update PrintVote set votes=" & Val(row.Cells(4).Value) & ", status=@d4 where nickname=@d1 and post=@d2 and MatricNo=@d3"
                        cmd = New SqlCommand(cb2)
                        cmd.Connection = con
                        cmd.Parameters.AddWithValue("@d1", row.Cells(3).Value)
                        cmd.Parameters.AddWithValue("@d2", row.Cells(2).Value)
                        cmd.Parameters.AddWithValue("@d3", row.Cells(1).Value)
                    cmd.Parameters.AddWithValue("@d4", txtStatusW.Text)
                    cmd.ExecuteReader()
                    con.Close()
                    'End If
                Else

                    'code to insert PrintVotes
                    'that is code to copy each record in the gridview to PrintVotes
                    con = New SqlConnection(cs)
                    con.Open()
                    Dim cb1 As String = "insert into PrintVote(StudName, MatricNo, Post, Nickname, Votes, Status) VALUES (@d1,@d2,@d3,@d4,@d5,@d6)"
                    cmd = New SqlCommand(cb1)
                    cmd.Connection = con
                    cmd.Parameters.AddWithValue("@d1", row.Cells(0).Value)
                    cmd.Parameters.AddWithValue("@d2", row.Cells(1).Value)
                    cmd.Parameters.AddWithValue("@d3", row.Cells(2).Value)
                    cmd.Parameters.AddWithValue("@d4", row.Cells(3).Value)
                    cmd.Parameters.AddWithValue("@d5", row.Cells(4).Value)
                    cmd.Parameters.AddWithValue("@d6", txtStatusW.Text)
                    cmd.ExecuteReader()
                    con.Close()

                End If
                con.Close()
            Next

            'LogFunc(lblUser.Text, "added the new Purchase having Invoice No. '" & txtInvoiceNo.Text & "'")
            'MessageBox.Show("Successfully saved", "Result Processing", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub FrmElectRes_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Getdata1()
    End Sub

    Private Sub BtnGen_Click(sender As Object, e As EventArgs) Handles btnGen.Click
        Me.Close()
    End Sub

    Public Sub GetWinner()
        Try
            For Each row As DataGridViewRow In dgw.Rows
                con = New SqlConnection(cs)
                con.Open()
                Dim ct As String = "Select Post, Nickname, Votes, MatricNo from Temp_PB where Post=@d1 and Nickname=@d2 and MatricNo=@d3"
                cmd = New SqlCommand(ct)
                cmd.Connection = con
                'cmd.Parameters.AddWithValue("@d1", row.Cells(2).Value)
                cmd.Parameters.AddWithValue("@d1", txtPost.Text)
                cmd.Parameters.AddWithValue("@d2", row.Cells(3).Value)
                cmd.Parameters.AddWithValue("@d3", row.Cells(1).Value)
                rdr = cmd.ExecuteReader()
                If rdr.Read() Then
                    '   nothing here
                Else

                    'insert into Temp_PB
                    con = New SqlConnection(cs)
                    con.Open()
                    Dim cb3 As String = "insert into Temp_PB(MatricNo, Post, Nickname, Votes) VALUES (@d1,@d2,@d3,@d4)"
                    cmd = New SqlCommand(cb3)
                    cmd.Connection = con
                    cmd.Parameters.AddWithValue("@d1", row.Cells(1).Value)
                    ' cmd.Parameters.AddWithValue("@d2", row.Cells(2).Value)
                    cmd.Parameters.AddWithValue("@d2", txtPost.Text)
                    cmd.Parameters.AddWithValue("@d3", row.Cells(3).Value)
                    cmd.Parameters.AddWithValue("@d4", row.Cells(4).Value)
                    cmd.ExecuteReader()
                    con.Close()

                    'CHECK if post exist in temp_winner
                    con = New SqlConnection(cs)
                    con.Open()
                    Dim ctA As String = "Select Post from Temp_Winner where Post=@d1"
                    cmd = New SqlCommand(ctA)
                    cmd.Connection = con
                    'cmd.Parameters.AddWithValue("@d1", row.Cells(2).Value)
                    cmd.Parameters.AddWithValue("@d1", txtPost.Text)
                    rdr = cmd.ExecuteReader()
                    If rdr.Read() Then
                        '   code to load the the existing votes in the temp_winner table 
                        con = New SqlConnection(cs)
                        con.Open()
                        cmd = con.CreateCommand()
                        cmd.CommandText = "SELECT RTRIM(Votes) FROM Temp_Winner Where Post=@d1"
                        'cmd.Parameters.AddWithValue("@d1", row.Cells(2).Value)
                        cmd.Parameters.AddWithValue("@d1", txtPost.Text)
                        'cmd.Parameters.AddWithValue("@d2", row.Cells(3).Value)
                        'cmd.Parameters.AddWithValue("@d3", row.Cells(1).Value)
                        rdr = cmd.ExecuteReader()
                        If rdr.Read() Then
                            lblTotVote.Text = rdr.GetValue(0)
                        End If

                        ' code to compare the existing vote in the table temp_winner
                        ' with the new votes of the incoming person.

                        'if greater than
                        If Val(lblTotVote.Text) > Val(row.Cells(4).Value) Then
                            'insert into Winner
                            con = New SqlConnection(cs)
                            con.Open()
                            Dim cb6 As String = "insert into Winner(StudName, MatricNo, Post, Nickname, Votes, Status) VALUES (@d1,@d2,@d3,@d4,@d5,@d6)"
                            cmd = New SqlCommand(cb6)
                            cmd.Connection = con
                            cmd.Parameters.AddWithValue("@d1", row.Cells(0).Value)
                            cmd.Parameters.AddWithValue("@d2", row.Cells(1).Value)
                            'cmd.Parameters.AddWithValue("@d3", row.Cells(2).Value)
                            cmd.Parameters.AddWithValue("@d3", txtPost.Text)
                            cmd.Parameters.AddWithValue("@d4", row.Cells(3).Value)
                            cmd.Parameters.AddWithValue("@d5", row.Cells(4).Value)
                            cmd.Parameters.AddWithValue("@d6", txtStatusR.Text)
                            cmd.ExecuteReader()
                            con.Close()

                            'if equal to
                        ElseIf Val(lblTotVote.Text) = Val(row.Cells(4).Value) Then
                            ' update temp_winner and set status = Tie
                            con = New SqlConnection(cs)
                            con.Open()
                            Dim cb7 As String = "Update Temp_Winner set status=@d1 where Post=@d2 and Votes=@d3"
                            cmd = New SqlCommand(cb7)
                            cmd.Connection = con
                            cmd.Parameters.AddWithValue("@d1", txtStatusT.Text)
                            cmd.Parameters.AddWithValue("@d2", txtPost.Text)
                            cmd.Parameters.AddWithValue("@d3", Val(lblTotVote.Text))
                            cmd.ExecuteReader()
                            con.Close()

                            ' update winner and set status = Tie
                            con = New SqlConnection(cs)
                            con.Open()
                            Dim cb8 As String = "Update Winner set status=@d1 where Post=@d2 and Votes=@d3"
                            cmd = New SqlCommand(cb8)
                            cmd.Connection = con
                            cmd.Parameters.AddWithValue("@d1", txtStatusT.Text)
                            cmd.Parameters.AddWithValue("@d2", txtPost.Text)
                            cmd.Parameters.AddWithValue("@d3", Val(lblTotVote.Text))
                            cmd.ExecuteReader()
                            con.Close()

                            'insert into Winner
                            con = New SqlConnection(cs)
                            con.Open()
                            Dim cb9 As String = "insert into Winner(StudName, MatricNo, Post, Nickname, Votes, Status) VALUES (@d1,@d2,@d3,@d4,@d5,@d6)"
                            cmd = New SqlCommand(cb9)
                            cmd.Connection = con
                            cmd.Parameters.AddWithValue("@d1", row.Cells(0).Value)
                            cmd.Parameters.AddWithValue("@d2", row.Cells(1).Value)
                            'cmd.Parameters.AddWithValue("@d3", row.Cells(2).Value)
                            cmd.Parameters.AddWithValue("@d3", txtPost.Text)
                            cmd.Parameters.AddWithValue("@d4", row.Cells(3).Value)
                            cmd.Parameters.AddWithValue("@d5", row.Cells(4).Value)
                            cmd.Parameters.AddWithValue("@d6", txtStatusT.Text)
                            cmd.ExecuteReader()
                            con.Close()

                            'if less than
                        ElseIf Val(lblTotVote.Text) < Val(row.Cells(4).Value) Then
                            ' update temp_winner and set status = Runner-up
                            con = New SqlConnection(cs)
                            con.Open()
                            Dim cb10 As String = "Update Temp_Winner set StudName=@d1, MatricNo=@d2, Nickname=@d4, Votes=@d5, status=@d6 where Post=@d3"
                            cmd = New SqlCommand(cb10)
                            cmd.Connection = con
                            cmd.Parameters.AddWithValue("@d1", row.Cells(0).Value)
                            cmd.Parameters.AddWithValue("@d2", row.Cells(1).Value)
                            'cmd.Parameters.AddWithValue("@d3", row.Cells(2).Value)
                            cmd.Parameters.AddWithValue("@d3", txtPost.Text)
                            cmd.Parameters.AddWithValue("@d4", row.Cells(3).Value)
                            cmd.Parameters.AddWithValue("@d5", row.Cells(4).Value)
                            cmd.Parameters.AddWithValue("@d6", txtStatusW.Text)
                            cmd.ExecuteReader()
                            con.Close()

                            ' update winner and set status = Runner-up
                            con = New SqlConnection(cs)
                            con.Open()
                            Dim cb11 As String = "Update Winner set status=@d1 where Post=@d2"
                            cmd = New SqlCommand(cb11)
                            cmd.Connection = con
                            cmd.Parameters.AddWithValue("@d1", txtStatusR.Text)
                            cmd.Parameters.AddWithValue("@d2", txtPost.Text)
                            cmd.ExecuteReader()
                            con.Close()

                            'insert into Winner
                            con = New SqlConnection(cs)
                            con.Open()
                            Dim cb12 As String = "insert into Winner(StudName, MatricNo, Post, Nickname, Votes, Status) VALUES (@d1,@d2,@d3,@d4,@d5,@d6)"
                            cmd = New SqlCommand(cb12)
                            cmd.Connection = con
                            cmd.Parameters.AddWithValue("@d1", row.Cells(0).Value)
                            cmd.Parameters.AddWithValue("@d2", row.Cells(1).Value)
                            'cmd.Parameters.AddWithValue("@d3", row.Cells(2).Value)
                            cmd.Parameters.AddWithValue("@d3", txtPost.Text)
                            cmd.Parameters.AddWithValue("@d4", row.Cells(3).Value)
                            cmd.Parameters.AddWithValue("@d5", row.Cells(4).Value)
                            cmd.Parameters.AddWithValue("@d6", txtStatusW.Text)
                            cmd.ExecuteReader()
                            con.Close()

                        End If
                    Else
                        'insert into Temp_Winner
                        con = New SqlConnection(cs)
                        con.Open()
                        Dim cb4 As String = "insert into Temp_Winner(StudName, MatricNo, Post, Nickname, Votes, Status) VALUES (@d1,@d2,@d3,@d4,@d5,@d6)"
                        cmd = New SqlCommand(cb4)
                        cmd.Connection = con
                        cmd.Parameters.AddWithValue("@d1", row.Cells(0).Value)
                        cmd.Parameters.AddWithValue("@d2", row.Cells(1).Value)
                        ' cmd.Parameters.AddWithValue("@d3", row.Cells(2).Value)
                        cmd.Parameters.AddWithValue("@d3", txtPost.Text)
                        cmd.Parameters.AddWithValue("@d4", row.Cells(3).Value)
                        cmd.Parameters.AddWithValue("@d5", row.Cells(4).Value)
                        cmd.Parameters.AddWithValue("@d6", txtStatusW.Text)
                        cmd.ExecuteReader()
                        con.Close()

                        'insert into Winner
                        con = New SqlConnection(cs)
                        con.Open()
                        Dim cb5 As String = "insert into Winner(StudName, MatricNo, Post, Nickname, Votes, Status) VALUES (@d1,@d2,@d3,@d4,@d5,@d6)"
                        cmd = New SqlCommand(cb5)
                        cmd.Connection = con
                        cmd.Parameters.AddWithValue("@d1", row.Cells(0).Value)
                        cmd.Parameters.AddWithValue("@d2", row.Cells(1).Value)
                        'cmd.Parameters.AddWithValue("@d3", row.Cells(2).Value)
                        cmd.Parameters.AddWithValue("@d3", txtPost.Text)
                        cmd.Parameters.AddWithValue("@d4", row.Cells(3).Value)
                        cmd.Parameters.AddWithValue("@d5", row.Cells(4).Value)
                        cmd.Parameters.AddWithValue("@d6", txtStatusW.Text)
                        cmd.ExecuteReader()
                        con.Close()

                    End If

                    con.Close()
                End If
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class