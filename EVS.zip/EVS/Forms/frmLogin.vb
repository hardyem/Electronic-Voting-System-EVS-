﻿Imports System.Data.SqlClient
Public Class frmLogin
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End

    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If cmbUserType.Text = "" Then
            MessageBox.Show("Select User Type", "EVS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            cmbUserType.Focus()
            Exit Sub
        End If
        If txtUser.Text = "" Then
            MessageBox.Show("Enter Username", "EVS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtUser.Focus()
            Exit Sub
        End If
        If txtPass.Text = "" Then
            MessageBox.Show("Enter Password", "EVS", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtPass.Focus()
            Exit Sub
        End If

        Try

            con = New SqlConnection(cs)
            con.Open()
            cmd = con.CreateCommand()
            cmd.CommandText = "SELECT RTRIM(Username),RTRIM(Password) FROM Users where Username = @d1 and Password=@d2 and UserType=@d3"
            cmd.Parameters.AddWithValue("@d1", txtUser.Text)
            cmd.Parameters.AddWithValue("@d2", txtPass.Text)
            cmd.Parameters.AddWithValue("@d3", cmbUserType.Text)
            rdr = cmd.ExecuteReader()
            If rdr.Read() Then
                con = New SqlConnection(cs)
                con.Open()
                cmd = con.CreateCommand()
                cmd.CommandText = "SELECT RTRIM(UserType) FROM Users where Username=@d6 and Password=@d4 and UserType=@d5"
                cmd.Parameters.AddWithValue("@d6", txtUser.Text)
                cmd.Parameters.AddWithValue("@d4", txtPass.Text)
                cmd.Parameters.AddWithValue("@d5", cmbUserType.Text)
                rdr = cmd.ExecuteReader()

                'con.Close()
                ' Dim st As String = "Successfully logged in"

                '++++++++ CODE TO MAKE MAIN MENU SHOW USER TYPE, LIKE ADMIN, HARDYEM ETC

                If rdr.Read() Then
                    cmbUserType.Text = rdr.GetValue(0).ToString.Trim
                End If
                If (rdr IsNot Nothing) Then
                    rdr.Close()
                End If
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If


                If cmbUserType.Text = "Admin" Then
                    frmMain.lblUser.Text = txtUser.Text
                    frmMain.lblUserType.Text = cmbUserType.Text

                    frmMain.ElectionSetupToolStripMenuItem.Visible = True
                    frmMain.CourseRegistrationToolStripMenuItem.Visible = True
                    frmMain.SchoolToolStripMenuItem.Visible = True
                    frmMain.DepartmentToolStripMenuItem.Visible = True
                    frmMain.StudentsToolStripMenuItem.Visible = True
                    frmMain.ImportsToolStripMenuItem.Visible = True
                    frmMain.UtilitiesToolStripMenuItem.Visible = True
                    frmMain.ReportsToolStripMenuItem.Visible = True
                    frmMain.ToolStripMenuItem1.Visible = True

                    Dim st As String = "Successfully logged in"
                    LogFunc(txtUser.Text, st)
                    MsgBox("Successfully logged in !", MsgBoxStyle.Information, "ACCESS GRANTED")
                    Me.Hide()
                    frmMain.Show()
                ElseIf cmbUserType.Text = "Election Officer" Then
                    frmMain.lblUser.Text = txtUser.Text
                    frmMain.lblUserType.Text = cmbUserType.Text

                    frmMain.ElectionSetupToolStripMenuItem.Visible = False
                    frmMain.CourseRegistrationToolStripMenuItem.Visible = False
                    frmMain.SchoolToolStripMenuItem.Visible = False
                    frmMain.DepartmentToolStripMenuItem.Visible = False
                    frmMain.StudentsToolStripMenuItem.Visible = False
                    frmMain.ImportsToolStripMenuItem.Visible = False
                    frmMain.UtilitiesToolStripMenuItem.Visible = False
                    frmMain.ReportsToolStripMenuItem.Visible = False
                    frmMain.ToolStripMenuItem1.Visible = False

                    Dim st As String = "Successfully logged in"
                    LogFunc(txtUser.Text, st)
                    MsgBox("Successfully logged in !", MsgBoxStyle.Information, "ACCESS GRANTED")
                    Me.Hide()
                    frmMain.Show()
                ElseIf cmbUserType.Text = "Voter" Then
                    Try
                        'CODE TO CHECK IF ELECTION TIME IS STILL ON BEFORE ALLOWED TO VOTE
                        'If lblCTime.Text >= lblETime.Text Then
                        'MsgBox("Scheduled voting time is up !", MsgBoxStyle.Critical, "ELECTION")
                        'ElseIf lblCTime.Text <= lblSTime.Text Then
                        'MsgBox("Not yet time for voting !", MsgBoxStyle.Critical, "ELECTION")
                        'Else
                        con = New SqlConnection(cs)
                        con.Open()
                        Dim st1 As String = "End Election"
                        Dim ct As String = "select RTRIM(username) from Users where Username=@d1"
                        cmd = New SqlCommand(ct)
                        cmd.Parameters.AddWithValue("@d1", st1)
                        cmd.Connection = con
                        rdr = cmd.ExecuteReader()

                        If rdr.Read() Then
                            MsgBox("Scheduled voting time is up !", MsgBoxStyle.Critical, "ELECTION")
                            'txtUser.Text = ""
                            txtUser.Focus()

                        Else

                            con = New SqlConnection(cs)
                            con.Open()
                            Dim ct1 As String = "select MatricNo from Ballot where MatricNo=@d1"
                            cmd = New SqlCommand(ct1)
                            cmd.Parameters.AddWithValue("@d1", txtUser.Text)
                            cmd.Connection = con
                            rdr = cmd.ExecuteReader()

                            If rdr.Read() Then
                                MessageBox.Show("You can not vote twice!", "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                                txtUser.Text = ""
                                txtUser.Focus()
                            Else
                                con = New SqlConnection(cs)
                                con.Open()
                                Dim ct11 As String = "select RTRIM(MatricNo), RTRIM(SchoolName), RTRIM(Lev) from Voters where MatricNo=@d1"
                                cmd = New SqlCommand(ct11)
                                cmd.Parameters.AddWithValue("@d1", txtUser.Text)
                                cmd.Parameters.AddWithValue("@d2", lblLev.Text)
                                cmd.Parameters.AddWithValue("@d3", lblSch.Text)
                                cmd.Connection = con
                                rdr = cmd.ExecuteReader()

                                If rdr.Read() Then
                                    'CODE TO LOAD EACH VOTERS DETAILS
                                    con = New SqlConnection(cs)
                                    con.Open()
                                    cmd = con.CreateCommand()
                                    cmd.CommandText = "SELECT RTRIM(SchoolName), RTRIM(Lev) FROM Voters WHERE MatricNo= @d1"
                                    cmd.Parameters.AddWithValue("@d1", txtUser.Text)
                                    rdr = cmd.ExecuteReader()
                                    If rdr.Read() Then
                                        lblSch.Text = rdr.GetValue(0)
                                        lblLev.Text = rdr.GetValue(1)
                                    End If


                                    MsgBox("Successfully logged in !", MsgBoxStyle.Information, "ACCESS GRANTED")
                                    frmBallot.lblUser.Text = txtUser.Text
                                    frmBallot.lblUserType.Text = cmbUserType.Text
                                    frmBallot.lblSch.Text = lblSch.Text
                                    frmBallot.lblLev.Text = lblLev.Text

                                    frmBallot.DataGridView1.Rows.Clear()
                                    frmBallot.dgw.Rows.Clear()
                                    frmBallot.Picture.Image = My.Resources.photo
                                    frmBallot.GetdataB()
                                    frmBallot.Getdata1()
                                    frmBallot.electName()
                                    Me.Hide()
                                    frmBallot.Show()
                                Else

                                    'CODE TO LOAD EACH VOTERS DETAILS
                                    con = New SqlConnection(cs)
                                    con.Open()
                                    cmd = con.CreateCommand()
                                    cmd.CommandText = "SELECT RTRIM(SchoolName), RTRIM(Lev) FROM Aspirants WHERE MatricNo= @d1"
                                    cmd.Parameters.AddWithValue("@d1", txtUser.Text)
                                    rdr = cmd.ExecuteReader()
                                    If rdr.Read() Then
                                        lblSch.Text = rdr.GetValue(0)
                                        lblLev.Text = rdr.GetValue(1)
                                    End If


                                    MsgBox("Successfully logged in !", MsgBoxStyle.Information, "ACCESS GRANTED")
                                    frmBallot.lblUser.Text = txtUser.Text
                                    frmBallot.lblUserType.Text = cmbUserType.Text
                                    frmBallot.lblSch.Text = lblSch.Text
                                    frmBallot.lblLev.Text = lblLev.Text

                                    frmBallot.DataGridView1.Rows.Clear()
                                    frmBallot.dgw.Rows.Clear()
                                    frmBallot.Picture.Image = My.Resources.photo
                                    frmBallot.GetdataB()
                                    frmBallot.Getdata1()
                                    frmBallot.electName()
                                    Me.Hide()
                                    frmBallot.Show()
                                    'End If
                                End If
                                If (rdr IsNot Nothing) Then
                                    rdr.Close()
                                End If
                            End If
                            Return
                        End If

                    Catch ex As Exception
                        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.[Error])
                    End Try
                Else
                    MsgBox("Login is Failed...Try again !", MsgBoxStyle.Critical, "ACCESS DENIED")
                    txtUser.Text = ""
                    txtPass.Text = ""
                    txtUser.Focus()
                End If

                con.Close()
                'Me.Hide()
                'frmMain.Show()

                '                     OR

                'I CAN JUST MAKE A COMBO BOX THAT HAS (admin,voters)
                ' then transfer the content with FRMMAIN.LBLUSER.TEXT=COMBOUSER.TEXT 
                'WITHOUT EVEN USING ANY USERTYPE FIELD IN THE DATABASE TABLE OF LOGIN
                '+++++++++++++ STOPPED HERE ++++++++++++++++++++++++

                'frmVoters.Show()

            Else
                MsgBox("Login is Failed...Try again !", MsgBoxStyle.Critical, "ACCESS DENIED")
                txtUser.Text = ""
                txtPass.Text = ""
                txtUser.Focus()
            End If
            cmd.Dispose()
            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Me.Hide()
        ' frmChangePass.Show()
        ' frmChangePass.UserID.Text = ""
        ' frmChangePass.OldPassword.Text = ""
        ' frmChangePass.NewPassword.Text = ""
        ' frmChangePass.ConfirmPassword.Text = ""
        ' frmChangePass.UserID.Focus()
    End Sub

    Private Sub frmLogin_Load(sender As Object, e As EventArgs) Handles Me.Load
        AcceptButton = btnLogin
        cmbUserType.Text = "Voter"
        electTime()
    End Sub

    Public Sub electTime()
        'CODE TO CHECK FOR VOTING TIME
        con = New SqlConnection(cs)
        con.Open()
        cmd = con.CreateCommand()
        cmd.CommandText = "SELECT RTRIM(StartTime), RTRIM(EndTime) FROM SetElection"
        'cmd.Parameters.AddWithValue("@d1", lblElectName.Text)
        rdr = cmd.ExecuteReader()
        If rdr.Read() Then
            lblSTime.Text = rdr.GetValue(0)
            lblETime.Text = rdr.GetValue(1)
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        lblCTime.Text = DateTime.Now.ToLongTimeString

    End Sub

    Private Sub lblCTime_TextChanged(sender As Object, e As EventArgs) Handles lblCTime.TextChanged
        If lblCTime.Text = lblETime.Text Then
            con = New SqlConnection(cs)
            con.Open()
            Dim st As String = "End Election"
            Dim cb As String = "insert into Users(Username, UserType, Password) VALUES (@d1,@d2,@d3)"
            cmd = New SqlCommand(cb)
            cmd.Connection = con
            cmd.Parameters.AddWithValue("@d1", st)
            cmd.Parameters.AddWithValue("@d2", st)
            cmd.Parameters.AddWithValue("@d3", lblETime.Text)
            'cmd.Parameters.AddWithValue("@d7", Now)
            cmd.ExecuteReader()
            con.Close()
        End If
    End Sub
End Class