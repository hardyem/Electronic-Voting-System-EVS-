﻿Module ModConn
    Public Const cs As String = "Data Source=DPROGRAMMER;Initial Catalog=EVS;Integrated Security=True"
    'Public Const cs As String = "Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFileName=|DataDirectory|\Data\EVS.mdf;Integrated Security=True"
End Module
